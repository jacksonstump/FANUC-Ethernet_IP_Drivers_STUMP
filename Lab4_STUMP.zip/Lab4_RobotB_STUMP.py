import socket
import pickle

# Client configuration
server_ip = 'Robot_A_IP_Address'  # Replace with Robot A's IP address
server_port = 12345  # Replace with the same port number used on Robot A

# Sample list of coordinates
coordinates = [HOME, INT_Dice1, Dice_Grab1, INT_DICE2, DICE_DROP1, INT_DICE3, Dice_Grab2, DICE_DROP2, Rotate]

# Create a socket object
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server (Robot A)
client_socket.connect((server_ip, server_port))
print(f"Connected to {server_ip}:{server_port}")

try:
    # Serialize and send the coordinates using pickle
    data_to_send = pickle.dumps(coordinates)
    client_socket.send(data_to_send)
    print(f"Sent coordinates to Robot A")

except KeyboardInterrupt:
    print("Client terminated by user")

finally:
    # Close the socket
    client_socket.close()
